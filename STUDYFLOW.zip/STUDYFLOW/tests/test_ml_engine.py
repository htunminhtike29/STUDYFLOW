import json
import unittest
from io import BytesIO
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
import pandas as pd

from ml_engine import FEATURES, available_model, deserialize, feature_frame, recommendations
from train_model import DATA, clean, metrics, serialize, synthetic_data, train, train_demo
from database import Database


class LearningTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.frame = pd.read_csv(DATA)
        cls.predictor = train(cls.frame)

    def test_reproducible_labeled_dataset(self):
        pd.testing.assert_frame_equal(self.frame, synthetic_data(), check_dtype=False)
        self.assertEqual(set(self.frame.source), {"synthetic"})
        self.assertEqual(len(self.frame), 400)
        self.assertTrue(self.frame.actual_hours.gt(0).all())

    def test_clean_invalid_rows_and_columns(self):
        dirty = self.frame.copy()
        dirty.loc[0, "actual_hours"] = np.nan
        dirty.loc[1, "estimated_hours"] = -1
        dirty.loc[2, "difficulty"] = 6
        self.assertEqual(len(clean(dirty)), 397)
        for invalid in [dirty.iloc[:10], dirty.drop(columns=["actual_hours"])]:
            with self.assertRaises(ValueError):
                clean(invalid)

    def test_features_are_available_at_creation(self):
        self.assertEqual(feature_frame(2, -1, 4).columns.tolist(), FEATURES)
        self.assertEqual(list(self.predictor.model.feature_names_in_), FEATURES)
        self.assertNotIn("actual_hours", FEATURES)
        for args in [(0, 1, 1), (2.5, 1, 1), (3, 1.2, 1), (3, 2, -1),
                     (3, 2, np.nan), (3, np.inf, 1), (3, 1, "x")]:
            with self.assertRaises(ValueError):
                feature_frame(*args)

    def test_holdout_metrics_and_baseline(self):
        m = self.predictor.meta
        self.assertEqual((m["train_size"], m["test_size"]), (320, 80))
        y = np.array(m["holdout"]["actual"])
        for label, field in [("regression", "prediction"), ("baseline", "baseline")]:
            err = y - m["holdout"][field]
            self.assertAlmostEqual(m[label]["MAE"], abs(err).mean())
            self.assertAlmostEqual(m[label]["MSE"], (err**2).mean())
            self.assertAlmostEqual(m[label]["RMSE"], np.sqrt((err**2).mean()))
            self.assertAlmostEqual(m[label]["R²"], 1-(err**2).sum()/((y-y.mean())**2).sum())
        self.assertIsNone(metrics(np.array([2, 2]), [3, 2])["R²"])

    def test_predict_and_explain_persisted_model(self):
        restored = deserialize(BytesIO(serialize(self.predictor)))
        result = restored.predict(4, 3, 4)
        self.assertAlmostEqual(result["raw"], sum(result["terms"].values()) + restored.meta["intercept"])
        self.assertEqual(result["hours"], self.predictor.predict(4, 3, 4)["hours"])
        self.assertEqual(result["outside"], [])
        self.assertIn("estimated_hours", restored.predict(5, 1, 500)["outside"])

    def test_clipping_negative_and_extreme_predictions(self):
        np.testing.assert_equal(recommendations(np.array([-10, 2.37, 1e6]), 30), [.1, 2.4, 30])
        with self.assertRaises(ValueError):
            recommendations(np.array([np.nan]), 30)
        self.assertEqual(self.predictor.predict(1, 9000, .1)["hours"], .1)

    def test_saved_outputs_and_unavailable_model(self):
        with TemporaryDirectory() as tmp:
            folder = Path(tmp)
            db = Database(folder / "study.db")
            db.initialize()
            path = folder / "study_model.joblib"
            self.assertIsNone(available_model(db, "A", path)[0])
            path.write_bytes(b"damaged")
            self.assertIsNone(available_model(db, "A", path)[0])
            trained = train_demo(folder/"data.csv", folder)
            restored, message = available_model(db, "A", path)
            self.assertEqual(message, "")
            self.assertEqual(restored.meta, json.loads((folder/"model_metadata.json").read_text()))
            self.assertEqual(trained.meta, restored.meta)
