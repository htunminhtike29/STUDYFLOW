"""Exercise the classroom workflow through actual Streamlit widgets."""
import os
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

from database import Database

APP = Path(__file__).resolve().parents[1] / "app.py"


class PlannerInterfaceTests(unittest.TestCase):
    def setUp(self):
        temp = TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        db_path = Path(temp.name) / "demo.db"
        env = patch.dict(os.environ, {"STUDYFLOW_DB": str(db_path)})
        env.start()
        self.addCleanup(env.stop)
        self.db = Database(db_path)
        self.app = AppTest.from_file(str(APP), default_timeout=20).run()

    def widget(self, kind, label):
        return next(w for w in getattr(self.app, kind) if w.label == label)

    def click(self, label):
        self.widget("button", label).click().run()
        self.assertFalse(self.app.exception, [e.message for e in self.app.exception])

    def navigate(self, view):
        self.app.radio(key="view").set_value(view).run()
        self.assertFalse(self.app.exception, [e.message for e in self.app.exception])

    def test_full_student_session(self):
        self.assertFalse(self.app.exception)
        self.app.radio(key="access").set_value("Register").run()
        for label, value in [("Student ID", "003"), ("Full name", "Demo Student"),
                             ("Password", "study1234"), ("Confirm password", "study1234")]:
            self.widget("text_input", label).set_value(value)
        self.click("Create account")
        self.assertEqual(len(self.db.tasks("003")), 3)
        self.widget("text_input", "Student ID").set_value("003")
        self.widget("text_input", "Password").set_value("study1234")
        self.click("Sign in")
        self.assertEqual(self.app.metric[0].value, "3")
        self.navigate("Weekly Plan")
        self.assertEqual(self.app.metric[0].value, "15 h")
        self.widget("number_input", "Hours per day").set_value(1.0)
        self.click("Save limit")
        self.assertEqual(self.app.metric[1].value, "8 h")
        self.assertEqual(len(self.app.warning), 3)
        self.navigate("Progress Tracker")
        self.click("+1.0 hour")
        self.assertEqual(self.db.tasks("003")[0].completed_hours, 1)
        self.navigate("Weekly Plan")
        self.assertEqual(self.app.metric[1].value, "7 h")
        self.navigate("Subjects & Tasks")
        self.widget("text_input", "Subject or task name").set_value("Lab report")
        self.click("Add task")
        lab = next(t for t in self.db.tasks("003") if t.subject_name == "Lab report")
        self.app.selectbox(key="manage_id").set_value(lab.task_id).run()
        self.app.text_input[-1].set_value("Lab journal")
        self.click("Save changes")
        self.assertIn("Lab journal", [t.subject_name for t in self.db.tasks("003")])
        self.assertTrue(self.widget("button", "Delete task").disabled)
        self.widget("checkbox", f"Delete Lab journal and its progress").check().run()
        self.click("Delete task")
        self.assertEqual(len(self.db.tasks("003")), 3)
        self.widget("checkbox", "Confirm changes to sample tasks").check().run()
        self.click("Remove sample tasks")
        self.assertEqual(self.db.tasks("003"), [])
        for view in ("Dashboard", "Weekly Plan", "Progress Tracker", "Subjects & Tasks"):
            self.navigate(view)
        self.widget("checkbox", "Confirm changes to sample tasks").check().run()
        self.click("Restore original samples")
        self.assertEqual(len(self.db.tasks("003")), 3)
        self.click("Logout")
        self.assertNotIn("student_id", self.app.session_state)
        self.assertFalse(self.app.metric)

    def test_hybrid_prediction_to_completion(self):
        import auth
        auth.register(self.db, "H", "Student H", "password8", "password8")
        self.widget("text_input", "Student ID").set_value("H")
        self.widget("text_input", "Password").set_value("password8")
        self.click("Sign in")
        self.navigate("Subjects & Tasks")
        self.widget("text_input", "Subject or task name").set_value("Capstone")
        self.widget("number_input", "Estimated study hours").set_value(4.)
        self.click("Predict study hours")
        self.widget("radio", "Planning budget").set_value("ML recommendation").run()
        self.click("Add task")
        t = next(t for t in self.db.tasks("H") if t.subject_name == "Capstone")
        self.assertEqual(t.total_hours, t.predicted_hours)
        self.navigate("Weekly Plan")
        self.navigate("Progress Tracker")
        self.app.selectbox(key="log_id").set_value(t.task_id).run()
        self.widget("number_input", "Custom study duration (hours)").set_value(12.)
        self.click("Log custom duration")
        self.assertTrue(self.app.warning)
        self.assertFalse(self.db.history("H"))
        self.click("Revise remaining workload")
        self.click("Confirm task is finished")
        self.assertEqual(self.db.history("H")[0]["actual_hours"], 12)
        self.navigate("AI & ML Insights")
        self.assertTrue(self.widget("button", "Train Personal Model").disabled)
        self.assertEqual(len(self.app.get("plotly_chart")), 5)
        self.widget("number_input", "Original estimate (hours)").set_value(8.).run()
        self.assertFalse(self.app.exception)

    def test_model_unavailable_keeps_planner_working(self):
        import auth
        auth.register(self.db, "Offline", "Offline Student", "password8", "password8")
        with patch("ml_engine.available_model", return_value=(None, "Model unavailable.")):
            self.widget("text_input", "Student ID").set_value("Offline")
            self.widget("text_input", "Password").set_value("password8")
            self.click("Sign in")
            self.navigate("Subjects & Tasks")
            self.assertTrue(self.widget("button", "Predict study hours").disabled)
            self.widget("text_input", "Subject or task name").set_value("Offline reading")
            self.click("Add task")
            task = next(t for t in self.db.tasks("Offline") if t.subject_name == "Offline reading")
            self.assertIsNone(task.predicted_hours)
            self.assertEqual(task.estimated_hours, task.total_hours)
            self.navigate("Weekly Plan")
            self.assertGreater(float(self.app.metric[0].value.split()[0]), 0)
