import sqlite3
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from decimal import Decimal
from pathlib import Path
from tempfile import TemporaryDirectory

import auth
from ai_engine import rank_tasks
from database import Database
from scheduler import schedule
from test_ai_engine import TODAY


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        tmp = TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.path = Path(tmp.name) / "studyflow.db"
        self.db = Database(self.path)
        self.db.initialize()
        auth.register(self.db, "001", "A Student", "pass1234", "pass1234", today=TODAY)

    def test_registration_login_and_duplicate(self):
        self.assertTrue(auth.authenticate(self.db, "001", "pass1234"))
        self.assertFalse(auth.authenticate(self.db, "1", "pass1234"))
        self.assertFalse(auth.authenticate(self.db, "001", "wrong"))
        with self.assertRaises(ValueError):
            auth.register(self.db, "001", "Other", "different", "different", today=TODAY)
        self.assertEqual(self.db.student("001")["name"], "A Student")
        self.assertEqual([t.deadline for t in self.db.tasks("001")],
                         [TODAY + timedelta(days=i) for i in (1, 3, 6)])
        encoded = self.db.password_hash("001")
        self.assertNotIn("pass1234", encoded)
        self.assertNotEqual(encoded, auth.hash_password("pass1234"))

    def test_input_validation(self):
        for sid, name, pwd, confirmation in [("", "A", "password", "password"),
                ("2", " ", "password", "password"), ("2", "A", "short", "short"),
                ("2", "A", "password", "mismatch")]:
            with self.assertRaises(ValueError):
                auth.register(self.db, sid, name, pwd, confirmation)
        for amount in [0, -1, "NaN", "inf", "abc", 0.0000001]:
            with self.assertRaises(ValueError):
                self.db.add_task("001", "Math", TODAY, 1, amount)
        for subject, due, difficulty in [(" ", TODAY, 1), ("Math", "bad", 1), ("Math", TODAY, 6)]:
            with self.assertRaises(ValueError):
                self.db.add_task("001", subject, due, difficulty, 2)
        with self.assertRaises(ValueError):
            self.db.set_limit("001", 25)

    def test_crud_persistent_progress_and_replan(self):
        self.db.samples("001", restore=False, today=TODAY)
        tid = self.db.add_task("001", "Reading", TODAY, 3, 2)
        self.db.edit_task("001", tid, "Seminar", TODAY, 2, 1)
        self.db.log_progress("001", tid, ".65")
        reopened = Database(self.path)
        reopened.initialize()
        t, = reopened.tasks("001")
        self.assertEqual((t.subject_name, t.difficulty, t.remaining), ("Seminar", 2, Decimal(".35")))
        self.assertEqual(schedule(rank_tasks([t], TODAY), TODAY, 3).total, Decimal(".35"))
        with self.assertRaises(ValueError):
            reopened.edit_task("001", tid, "Seminar", TODAY, 2, .5)
        reopened.log_progress("001", tid, ".50")
        self.assertEqual(reopened.tasks("001")[0].completed_hours, Decimal("1.15"))
        self.assertFalse(reopened.tasks("001")[0].finished)
        reopened.finish("001", tid)
        self.assertEqual(rank_tasks(reopened.tasks("001"), TODAY), [])
        reopened.set_limit("001", .125)
        self.assertEqual(self.db.student("001")["daily_limit"], .125)
        reopened.delete_task("001", tid)
        self.assertEqual(self.db.tasks("001"), [])

    def test_account_isolation_and_sample_provenance(self):
        auth.register(self.db, "002", "B", "pass1234", "pass1234", today=TODAY)
        own = self.db.add_task("001", "Statistics", TODAY, 5, .5)
        victim = self.db.tasks("002")[0]
        for call in [lambda: self.db.delete_task("001", victim.task_id),
                     lambda: self.db.log_progress("001", victim.task_id, 1),
                     lambda: self.db.edit_task("001", victim.task_id, "X", TODAY, 1, 1)]:
            with self.assertRaises(ValueError):
                call()
        starter = self.db.tasks("001")[1]
        self.db.edit_task("001", starter.task_id, "Renamed sample", TODAY, 1, 2)
        self.db.samples("001", restore=False, today=TODAY)
        self.assertEqual([t.task_id for t in self.db.tasks("001")], [own])
        for _ in range(2):
            self.db.samples("001", restore=True, today=TODAY)
        self.assertEqual(len(self.db.tasks("001")), 4)
        self.assertEqual(self.db.tasks("002")[0], victim)
        self.assertEqual(len(self.db.tasks("002")), 3)

    def test_constraints_and_rollback(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.add_task("missing", "History", TODAY, 1, 1)
        with self.assertRaises(sqlite3.IntegrityError):
            with self.db.connection(write=True) as conn:
                conn.execute("UPDATE students SET name=? WHERE student_id=?", ("Temporary", "001"))
                conn.execute("UPDATE tasks SET completed_hours=? WHERE student_id=?", (100, "001"))
        self.assertEqual(self.db.student("001")["name"], "A Student")
        with self.db.connection(write=True) as conn:
            conn.execute("DELETE FROM students WHERE student_id=?", ("001",))
        self.assertEqual(self.db.tasks("001"), [])

    def test_simultaneous_updates(self):
        tid = self.db.add_task("001", "Practice", TODAY, 2, 1)

        def record(_):
            try:
                self.db.log_progress("001", tid, ".25")
                return True
            except ValueError:
                return False

        with ThreadPoolExecutor(max_workers=4) as executor:
            self.assertEqual(sum(executor.map(record, range(8))), 8)
        t = next(t for t in self.db.tasks("001") if t.task_id == tid)
        self.assertEqual(t.completed_hours, 2)
        self.assertEqual(len(self.db.sessions("001")), 8)
