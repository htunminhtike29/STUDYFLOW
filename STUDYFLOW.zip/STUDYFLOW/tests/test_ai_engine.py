import unittest
from datetime import date, timedelta
from decimal import Decimal
from fractions import Fraction

from ai_engine import infer_urgency, normalize, rank_tasks
from models import Task

TODAY = date(2026, 1, 10)


def task(tid, days, difficulty, hours, done=0, name=None):
    return Task(tid, name or f"Subject {tid}", TODAY + timedelta(days=days), difficulty,
                Decimal(str(hours)), Decimal(str(done)))


class ReasoningTests(unittest.TestCase):
    def test_urgency_boundaries(self):
        for days, level in [(-10, 5), (0, 5), (1, 5), (2, 4), (3, 4), (4, 3),
                            (5, 3), (6, 2), (7, 2), (8, 1), (365, 1)]:
            with self.subTest(days=days):
                self.assertEqual(infer_urgency(days), level)

    def test_normalization(self):
        self.assertEqual(normalize(2, 4), Fraction(5, 2))
        self.assertEqual(normalize(4, 4), 5)
        self.assertEqual(normalize(0, 0), 0)

    def test_classroom_ranking(self):
        ranked = rank_tasks([task(3, 6, 3, 4), task(1, 1, 5, 5), task(2, 3, 4, 6)], TODAY)
        self.assertEqual([r.task.task_id for r in ranked], [1, 2, 3])
        self.assertEqual([r.score for r in ranked], [Fraction(29, 6), Fraction(21, 5), Fraction(77, 30)])
        self.assertEqual([f"{float(r.score):.2f}" for r in ranked], ["4.83", "4.20", "2.57"])
        for term in ["tomorrow", "critical", "5/5", "1.50 points", "5 h", "4.17/5", "4.83/5"]:
            self.assertIn(term, ranked[0].explain())

    def test_ties_and_unrounded_order(self):
        # 3 difficulty points plus full workload ties 4 difficulty points plus 70% workload.
        tied = [task(8, 3, 3, 10), task(7, 2, 4, 7), task(5, 2, 3, 10), task(4, 2, 3, 10)]
        ranked = rank_tasks(tied, TODAY)
        self.assertEqual(len({r.score for r in ranked}), 1)
        self.assertEqual([r.task.task_id for r in ranked], [4, 5, 7, 8])
        close = rank_tasks([task(1, 2, 2, 1000), task(2, 3, 2, 1000.01)], TODAY)
        self.assertEqual([r.task.task_id for r in close], [2, 1])
        self.assertEqual(round(float(close[0].score), 2), round(float(close[1].score), 2))

    def test_only_unfinished_normalize_and_overdue_explained(self):
        self.assertEqual(rank_tasks([], TODAY), [])
        r, = rank_tasks([task(1, 0, 5, 90, 90), task(2, -3, 2, 4, 2)], TODAY)
        self.assertEqual((r.workload, r.status), (5, "Overdue"))
        self.assertIn("Overdue by 3", r.explain())
