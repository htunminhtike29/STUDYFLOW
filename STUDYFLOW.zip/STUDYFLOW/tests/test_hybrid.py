from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

import auth
from ai_engine import rank_tasks
from database import Database, SCHEMA
from ml_engine import available_model
from scheduler import schedule
from train_model import train_personal

TODAY = date(2026, 4, 10)


class MigrationTests(unittest.TestCase):
    def test_original_schema_and_legacy_records(self):
        with TemporaryDirectory() as tmp:
            db = Database(Path(tmp)/"old.db")
            with db.connection() as conn:
                conn.executescript(SCHEMA)
                conn.execute("INSERT INTO students VALUES(?,?,?,?,?)",
                             ("007", "Lecturer", auth.hash_password("example17"), 2, TODAY.isoformat()))
                for amount in (.5, 2):
                    conn.execute("""INSERT INTO tasks(student_id,subject_name,deadline,difficulty,total_hours,
                                 completed_hours,created_at) VALUES(?,?,?,?,?,?,?)""",
                                 ("007","Essay", "2026-04-14", 4, 2, amount, "2026-04-10T12:00:00+00:00"))
            db.initialize()
            db.initialize()
            self.assertTrue(auth.authenticate(db, "007", "example17"))
            open_task, old_finished = db.tasks("007")
            self.assertTrue(old_finished.finished)
            self.assertEqual(open_task.remaining, Decimal("1.5"))
            self.assertEqual(db.sessions("007"), [])
            self.assertEqual(db.history("007"), [])
            db.finish("007", open_task.task_id)
            self.assertEqual(db.history("007")[0]["eligible"], 0)
            with db.connection() as conn:
                self.assertEqual(list(conn.execute("PRAGMA foreign_key_check")), [])


class HybridWorkflowTests(unittest.TestCase):
    def setUp(self):
        tmp = TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.db = Database(Path(tmp.name)/"planner.db")
        self.db.initialize()
        for sid in ("A", "B"):
            self.db.create_account(sid, sid, auth.hash_password("test1234"), 8, TODAY)
            self.db.samples(sid, restore=False, today=TODAY)

    def test_prediction_choice_sessions_and_restart(self):
        db = self.db
        model, _ = available_model(db, "A")
        pred = model.predict(4, 3, 4)["hours"]
        deadline = TODAY + timedelta(days=3)
        for source, expected in [("ML recommendation", pred), ("Original estimate", 4), ("Custom budget", 2.5)]:
            tid = db.add_task("A", source, deadline, 4, 4, source=source, budget=2.5,
                              predicted=pred, version=model.meta["version"], today=TODAY)
            t = next(task for task in db.tasks("A") if task.task_id == tid)
            self.assertEqual(t.total_hours, Decimal(str(expected)))
            self.assertEqual(t.estimated_hours, 4)
            self.assertEqual(t.predicted_hours, Decimal(str(pred)))
            self.assertEqual(schedule(rank_tasks([t], TODAY), TODAY, 8).total, t.total_hours)
            db.log_progress("A", tid, 9)
            self.assertFalse(next(task for task in db.tasks("A") if task.task_id == tid).finished)
            self.assertEqual(next(task for task in db.tasks("A") if task.task_id == tid).remaining, 0)
            db.revise_remaining("A", tid, 1.5)
            self.assertEqual(next(task for task in db.tasks("A") if task.task_id == tid).remaining, Decimal("1.5"))
            db.edit_task("A", tid, "Revised", deadline+timedelta(days=9), 1, 12)
            db.finish("A", tid)
            db.finish("A", tid)
            with self.assertRaises(ValueError):
                db.log_progress("A", tid, 1)
        reopened = Database(db.path)
        history = reopened.history("A")
        self.assertEqual(len(history), 3)
        self.assertEqual(len(reopened.sessions("A")), 3)
        for row in history:
            self.assertEqual((row["estimated_hours"], row["difficulty"], row["days_until_deadline"],
                              row["actual_hours"], row["predicted_hours"]), (4, 4, 3, 9, pred))
        self.assertEqual(rank_tasks(reopened.tasks("A"), TODAY), [])
        self.assertEqual(reopened.history("B"), [])
        self.assertEqual(reopened.sessions("B"), [])
        with self.assertRaises(ValueError):
            reopened.finish("B", tid)

    def test_no_inferred_or_sample_training_targets(self):
        self.db.samples("A", restore=True, today=TODAY)
        sample = self.db.tasks("A")[0]
        self.db.log_progress("A", sample.task_id, 1)
        self.db.finish("A", sample.task_id)
        tid = self.db.add_task("A", "Practice", TODAY, 3, 4)
        with self.assertRaises(ValueError):
            self.db.finish("A", tid)
        self.db.log_progress("A", tid, 6)
        self.assertEqual(self.db.history("A"), [])
        with self.assertRaisesRegex(ValueError, "30"):
            train_personal(self.db, "A")

    def test_personal_split_activation_isolation_and_retention(self):
        db = self.db
        for i in range(30):
            estimate = 1 + i % 5
            tid = db.add_task("A", f"Report {i}", TODAY, 3, estimate, today=TODAY)
            db.log_progress("A", tid, estimate + 2)
            db.finish("A", tid)
        first, accepted = train_personal(db, "A")
        self.assertTrue(accepted)
        self.assertEqual(first["holdout"]["actual"], [7, 3, 4, 5, 6, 7])
        self.assertEqual((first["train_size"], first["test_size"]), (24, 6))
        self.assertEqual(available_model(db,"A")[0].meta["version"], first["version"])
        self.assertEqual(available_model(db,"B")[0].meta["source"], "Synthetic demonstration")
        # Later tasks exactly match the baseline. A new candidate cannot beat zero error.
        for i in range(10):
            tid = db.add_task("A", f"Review {i}", TODAY, 2, 4, today=TODAY)
            db.log_progress("A", tid, 4)
            db.finish("A", tid)
        second, accepted = train_personal(db, "A")
        self.assertFalse(accepted)
        self.assertEqual(second["baseline"]["MAE"], 0)
        self.assertEqual(available_model(db,"A")[0].meta["version"], first["version"])
        self.assertEqual(len(db.model_reports("A")), 2)
        self.assertEqual(db.model_reports("B"), [])
