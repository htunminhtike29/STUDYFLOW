import random
import unittest
from datetime import timedelta
from decimal import Decimal

from ai_engine import rank_tasks
from scheduler import schedule
from test_ai_engine import TODAY, task


def plan(tasks, limit=3):
    return schedule(rank_tasks(tasks, TODAY), TODAY, limit)


class SchedulerTests(unittest.TestCase):
    def test_demo_default_and_restricted_capacity(self):
        tasks = [task(1, 1, 5, 5), task(2, 3, 4, 6), task(3, 6, 3, 4)]
        full = plan(tasks)
        self.assertEqual(full.total, 15)
        self.assertEqual(full.unmet, {})
        self.assertEqual(full.days[0].blocks, {1: 2, 2: 1})
        self.assertEqual(full.days[1].blocks, {1: 3})
        limited = plan(tasks, 1)
        self.assertEqual(limited.total, 7)
        self.assertEqual(limited.unmet, {1: 3, 2: 4, 3: 1})

    def test_queue_prefers_high_score_and_inclusive_deadline(self):
        p = plan([task(10, 1, 1, 3), task(9, 0, 5, 1)], 1)
        self.assertEqual(p.days[0].blocks, {9: 1})
        self.assertEqual(p.days[1].blocks, {10: 1})
        self.assertEqual(p.unmet, {10: 2})

    def test_group_cap_and_relaxation(self):
        p = plan([task(1, 5, 5, 1.5, name="Math"), task(2, 5, 5, 1, name="math"),
                  task(3, 6, 1, 4, name="History")], 3)
        self.assertEqual(p.days[0].blocks, {1: Decimal("1.5"), 2: Decimal(".5"), 3: 1})
        self.assertEqual(plan([task(1, 3, 1, 5)], 4).days[0].total, 4)

    def test_overdue_horizon_and_empty_plan(self):
        p = plan([task(1, -1, 5, 3), task(2, 7, 4, 9), task(3, 6, 5, 8)], 1)
        self.assertEqual(p.overdue, {1: 3})
        self.assertEqual(p.unmet, {3: 1})
        self.assertEqual(p.later, {2: 9})
        self.assertEqual(len(plan([]).days), 7)
        self.assertEqual(plan([]).total, 0)

    def test_fractional_limits_completion_and_recalculation(self):
        original = plan([task(1, 4, 3, ".625")], ".24")
        self.assertEqual([d.total for d in original.days[:3]], [Decimal(".24"), Decimal(".24"), Decimal(".145")])
        updated = plan([task(1, 4, 3, ".625", ".5")], ".24")
        self.assertEqual(updated.total, Decimal(".125"))
        self.assertEqual(plan([task(1, 4, 3, ".625", ".625")]).total, 0)

    def test_generated_cases_conserve_work(self):
        rng = random.Random(24)
        for case in range(60):
            tasks = [task(i, rng.randint(-2, 12), rng.randint(1, 5), Decimal(rng.randint(1, 60))/8,
                          name=f"Group {i%3}") for i in range(rng.randint(1, 15))]
            limit = Decimal(rng.randint(1, 32))/8
            p = plan(tasks, limit)
            for offset, day in enumerate(p.days):
                self.assertEqual(day.date, TODAY + timedelta(days=offset))
                self.assertLessEqual(day.total, limit)
                for tid, amount in day.blocks.items():
                    self.assertGreater(amount, 0)
                    self.assertLessEqual(day.date, tasks[tid].deadline)
            for t in tasks:
                tid = t.task_id
                assigned = sum(d.blocks.get(tid, 0) for d in p.days)
                balance = sum(d.get(tid, 0) for d in (p.unmet, p.later, p.overdue))
                self.assertEqual(assigned + balance, t.remaining, (case, tid))
